function validate(){
    var name = document.getElementById("ime").value;
    var phone = document.getElementById("mobitel").value;
    var email = document.getElementById("email").value;
    var message = document.getElementById("poruka").value;
    var error_message = document.getElementById("error_poruka");

    error_message.style.padding = "10px";

    var text;
    if(name.length < 5){
        text = "Molim vas unesite svoje ime";
        error_message.innerHTML = text;
        return false;
    }
    if(isNaN(phone) || phone.length != 10){
        text = "Molim vas unesite svoj broj mobitela";
        error_message.innerHTML = text;
        return false;
    }
    if(email.indexOf("@") == -1 || email.length < 6){
        text = "Molim vas unesite svoj email";
        error_message.innerHTML = text;
        return false;
    }
    if(message.length <= 140){
        text = "Unesite do 140 karaktera";
        error_message.innerHTML = text;
        return false;
    }
    alert("Uspješno ste nas kontaktirali");
    return true;
}